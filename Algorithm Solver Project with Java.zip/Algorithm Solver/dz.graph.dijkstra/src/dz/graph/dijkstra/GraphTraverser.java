
package dz.graph.dijkstra;

import dz.graph.dijkstra.frames.ds_graph.Edge;
import dz.graph.dijkstra.frames.ds_graph.Queue;
import dz.graph.dijkstra.frames.ds_graph.Vertex;
import java.util.ArrayList;
import javax.swing.JTextArea;


public class GraphTraverser {
    public static String resDFS="";
    public static String resBFS="";
    public static void depthFirstTraversal(Vertex start, ArrayList<Vertex> visitedVertices, JTextArea textArea) {
        try {
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        textArea.append("Visited: " + start.getData() + "\n");
        resDFS += start.getData() + "\n";

        for (Edge e : start.getEdges()) {
            Vertex neighbor = e.getEnd();
            if (!visitedVertices.contains(neighbor)) {
                visitedVertices.add(neighbor);
                textArea.append("Edge Selected: " + start.getData() + " -> " + neighbor.getData() + "\n");
                depthFirstTraversal(neighbor, visitedVertices, textArea);
            }
        }
    }
    public static void breadthFirstSearch(Vertex start, ArrayList<Vertex> visitedVertices, JTextArea textArea) {
        Queue visitQueue = new Queue();
        visitQueue.enqueue(start);
        visitedVertices.add(start);

        while (!visitQueue.isEmpty()) {
            try {
                Thread.sleep(1000); 
            } catch (InterruptedException e) {
                e.printStackTrace();
            }

            Vertex current = visitQueue.dequeue();
            textArea.append("Visited: " + current.getData() + "\n");

            for (Edge e: current.getEdges()) {
                Vertex neighbor = e.getEnd();
                if (!visitedVertices.contains(neighbor)) {
                    visitedVertices.add(neighbor);
                    visitQueue.enqueue(neighbor);
                    textArea.append("Edge Selected: " + current.getData() + " -> " + neighbor.getData() + "\n");
                }
            }
        }
    }
}
